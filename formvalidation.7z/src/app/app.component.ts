import { Component } from '@angular/core';
import {FormGroup,FormControl,Validators} from '@angular/forms'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'formvalidation';
  customerForm = new FormGroup({
    name: new FormControl('enter your name',[Validators.required,Validators.minLength(5)]),
    age : new FormControl('enter your age',[Validators.min(5)]),
    city : new FormControl('enter your city',[Validators.minLength(4)])

  })
  onSubmit(){
    console.log(this.customerForm.value);
  }
}
